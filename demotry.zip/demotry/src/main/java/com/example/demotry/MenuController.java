package com.example.demotry;

import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class MenuController {


    @FXML
    private VBox menuVBox;

    public void initialize() {
        // Populate menu items or perform any initialization here
        // For simplicity, this example doesn't add specific menu items
    }
}